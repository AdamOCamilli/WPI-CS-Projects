#include <sys/syscall.h>
#include <stdio.h>
#include <unistd.h>

#define __NR_cs3013_syscall1 377
#define __NR_open 5
#define __NR_close 6
#define __NR_read 3

long testCall1(void) {
  return (long) syscall(__NR_cs3013_syscall1);
}

long testOpen(void) {
  return (long) syscall(__NR_open,"/etc/motd");
}

long testClose(void) {
  return (long) syscall(__NR_close,2);
}

long testRead(void) {
  return (long) syscall(__NR_read,"~/Documents/virus.txt"); 
}

int main() {
  printf("The return values of the system calls are:\n");
  printf("\tcs3013_syscall1: %ld\n", testCall1());
  printf("\tOpen: %ld\n", testOpen());
  printf("\tClose: %ld\n", testClose());
  return 0;
}
