To Use Chat Program:

1) Navigate to the Source_Code folder
2) run 'make'
3) Open additional terminals (one for each client) and navigate to Source_Code/ in each
4) In main terminal run server: './server'
5) In separate terminals run clients to connect to server: './client 127.0.0.1'
6) Chat away in clients. Chat itself is displayed in server terminal.
